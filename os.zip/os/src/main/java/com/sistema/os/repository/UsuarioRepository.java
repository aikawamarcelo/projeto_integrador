package com.sistema.os.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;

import com.sistema.os.model.Usuario;



public interface UsuarioRepository extends JpaRepository<Usuario, String>{

     
	List<Usuario> findAll();     
     
     
}


