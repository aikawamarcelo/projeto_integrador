package com.sistema.os.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.sistema.os.model.Usuario;
import com.sistema.os.repository.UsuarioRepository;
import com.sistema.os.resourcenotfoundexception.ResourceNotFoundException;

@CrossOrigin
@RestController
@RequestMapping("/principal/usuario/")
public class UsuarioController {

	@Autowired
	private UsuarioRepository ur;
	
	@GetMapping("/usuarios")
	public List<Usuario> ListarUsuarios() {
		   return ur.findAll();
	}
	
	@PostMapping("/usuarios")
	public Usuario criarUsuario(@RequestBody Usuario usuario) {
	       return ur.save(usuario);   
	}
	

	@GetMapping("usuarios/{cpf}")
	
	public ResponseEntity<Usuario> listarUsuarioPorId(@PathVariable String cpf){ 
   	 Usuario usuario = ur.findById(cpf).orElseThrow(() -> new ResourceNotFoundException(" O Usuário com o CPF "+ cpf + " Não existe!"));
   	return ResponseEntity.ok(usuario);
	}
     @PutMapping("/usuarios/{cpf}")
	public ResponseEntity<Usuario> alterarUsuario(@PathVariable String cpf, @RequestBody Usuario usuario_detalhes){ 
    	 Usuario usuario = ur.findById(cpf)
    		.orElseThrow(() -> new ResourceNotFoundException(" O Usuário com o CPF "+ cpf + " Não existe!"));
    	 
    	 usuario.setCpf(usuario_detalhes.getCpf());
    	 usuario.setLogin(usuario_detalhes.getLogin());
    	 usuario.setSenha(usuario_detalhes.getSenha());
    	 usuario.setEmail(usuario_detalhes.getEmail());
    	 usuario.setTelefone(usuario_detalhes.getTelefone());
    	 usuario.setPerfil(usuario_detalhes.getPerfil());
    	 Usuario alterarUsuario = ur.save(usuario);
    	 return ResponseEntity.ok(alterarUsuario);
    	 
     }
     
     @DeleteMapping("/usuarios/{cpf}")
     public ResponseEntity <Map<String,Boolean>> excluirUsuario(@PathVariable String cpf){
    	Usuario usuario = ur.findById(cpf)
    		    .orElseThrow(() -> new ResourceNotFoundException("Usuário não existe com o cpf: " + cpf + " não existe!"));
    	
    	ur.delete(usuario);
    	Map<String, Boolean> response = new HashMap<>();
    	response.put("Usuário excluído com sucesso! ", Boolean.TRUE);
    	return ResponseEntity.ok(response);
    	
     }
     
}
