package com.sistema.os.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sistema.os.model.Cliente;
import com.sistema.os.repository.ClienteRepository;
import com.sistema.os.resourcenotfoundexception.ResourceNotFoundException;

@CrossOrigin
@RestController
@RequestMapping("/principal/")
public class ClienteController {
	
	@Autowired
	private ClienteRepository cr;
	
	@GetMapping("/clientes")
	public List <Cliente> listarClientes(){
		return cr.findAll();
	}
	
	@PostMapping("/clientes")
	public Cliente cadastrarCliente(@RequestBody Cliente cliente) {
		   return cr.save(cliente);
	}
	
	@GetMapping("/clientes/{cpf_cnpj}")
	public ResponseEntity<Cliente> listarClienteporId(@PathVariable String cnpj_cpf){
		   Cliente cliente = cr.findById(cnpj_cpf).orElseThrow(() -> new ResourceNotFoundException("O Cliente com o CNPJ ou CPF: "+ cnpj_cpf + " não existe! "  ));
		   return ResponseEntity.ok(cliente);
	}
	
	@PutMapping("/clientes/{cpf_cnpj}")
		
	public ResponseEntity<Cliente> alterarCliente(@PathVariable String cpf_cnpj, @RequestBody Cliente cliente_detalhes){
		Cliente cliente = cr.findById(cpf_cnpj).orElseThrow(() -> new ResourceNotFoundException("O Cliente com o CNPJ ou CPF: " + cpf_cnpj + " não existe! "));
		
		cliente.setCpf_cnpj(cliente.getCpf_cnpj());
		cliente.setNome(cliente_detalhes.getNome());
		cliente.setEmail(cliente_detalhes.getEmail());
		cliente.setTelefone(cliente_detalhes.getTelefone());
		cliente.setCep(cliente_detalhes.getCep());
		cliente.setRua(cliente_detalhes.getRua());
		cliente.setNumero(cliente_detalhes.getNumero());
		cliente.setBairro(cliente_detalhes.getBairro());
		cliente.setCidade(cliente_detalhes.getCidade());
		cliente.setEstado(cliente_detalhes.getEstado());
		Cliente alterarCliente = cr.save(cliente);
		      return ResponseEntity.ok(alterarCliente);
		
	     	 
	}
		
	@DeleteMapping("/clientes/{cpf_cnpj}")
    public ResponseEntity <Map<String,Boolean>> excluirCliente(@PathVariable String cpf_cnpj){
		Cliente cliente = cr.findById(cpf_cnpj).orElseThrow(() -> new ResourceNotFoundException("O cliente com o CPF ou CNPJ: " + cpf_cnpj + " não existe!"));
	        cr.delete(cliente);
	    Map<String, Boolean> response = new HashMap<>();    
	        response.put("Cliente Excluído com sucesso!", Boolean.TRUE);
	        return ResponseEntity.ok(response);
		
	}

}
